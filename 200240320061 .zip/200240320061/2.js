function submit()
        {
            var username = document.querySelector("#username").value;
            document.querySelector("#username1").innerHTML = username;
            var password = document.querySelector("#password").value;
            document.querySelector("#password1").innerHTML = password;
            var email = document.querySelector("#email").value;
            document.querySelector("#email1").innerHTML = email;
            
        }  
        